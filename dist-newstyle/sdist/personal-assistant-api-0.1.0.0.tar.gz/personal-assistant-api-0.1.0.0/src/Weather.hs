module Weather (weather) where

import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as BC
import qualified Data.ByteString.Lazy as L
import qualified Data.ByteString.Lazy.Char8 as LC
import Network.HTTP.Simple

-- weather ::
weather = undefined

myToken :: BC.ByteString
myToken = "cc0e99f5f6971474f1bafc6aba7d963c"

noaaHost :: BC.ByteString
noaaHost = "www.ncdc.noaa.gov"

apiPath :: BC.ByteString
apiPath = "/cdo-web/api/v2/datasets"

-- api.openweathermap.org/data/2.5/weather?id={city id}&appid={your api key}
-- Toronto id -> 5174095

-- to consult we get the city id, from the table
-- when we register the user, the user type city and country and with that data we look in the json object and we save the city name and the city id